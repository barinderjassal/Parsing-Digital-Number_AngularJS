# Parse Digital Numbers  

## Overview

This application allows the user to upload a text file of 7-segment digital numbers(containing '_' and '|'), and outputs a list with the parsed numbers. 7-segment numbers are formed by combining 3 lines of the text file in which each line has some particular characters('_' or '|') at certain indexes to form a digital number and then output is one parsed number per line.

### How to run  

Unzip User Story-1_Parse Digital Numbers folder to your local machine and run index.html file.  